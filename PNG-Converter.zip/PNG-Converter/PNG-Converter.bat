@echo off
rem Double-click to open, or drag a folder onto this file.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0PNG-Converter.ps1" "%~1"
