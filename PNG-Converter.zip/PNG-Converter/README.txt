PNG Converter
=============
Batch-converts PNG texture maps. Three modes:

  Smart TIFF (default) - saves disk space, no visible quality loss
    16-bit kept : normal, height, displacement, bump, anisotropy/rotation/flow
    8-bit       : basecolor/albedo/diffuse, roughness/gloss, metallic, AO,
                  sheen, specular, opacity, emission, SSS, coat, ARM/ORM, preview
    Unrecognized names keep their original bit depth (logged as such).
    Grayscale maps are stored as 1 channel. ZIP compression.

  TIFF (lossless)  - keeps original bit depth for every map
  JPG              - 8-bit, adjustable quality, transparency flattened on white

Map type is read from the file name, e.g.
  "aged cast copper metal height 8k"      -> height   (16-bit)
  "Poliigon_ConcreteWorn_8690_Normal"     -> normal   (16-bit)
  "Metal032_8K-PNG_NormalGL"              -> normal   (16-bit)
  "rock_wall_rough_4k"                    -> rough    (8-bit)
  "T_Rock_D" / "T_Rock_N" / "T_Rock_ORM"  -> diffuse 8 / normal 16 / ORM 8

HOW TO USE
1. Keep PNG-Converter.bat and PNG-Converter.ps1 in the same folder.
2. Double-click PNG-Converter.bat (or drag a folder onto it).
   First run: if ImageMagick is missing it offers to install it via winget
   (ImageMagick.Q16 - free, open source).
3. Pick the source folder, mode, and output:
   - Replace originals: converted file goes next to the PNG, PNG moves to
     the Recycle Bin (only after the new file was written successfully).
   - Separate folder: default is "<source>\converted", subfolders mirrored.
4. Click Convert. The log shows each map's detected type and size, and the
   total size saved at the end.

TIPS
- Try Smart mode on one material folder with "Separate folder" first.
- Speed: "CPU cores to use" = files converted at once (about 1 GB RAM each
  for 8K). "Recommended" leaves one core free. Both settings can be changed
  while converting. "Low priority" keeps C4D and other apps responsive.
  Uses CPU + RAM only, no GPU.
- "Skip files already converted" lets you re-run after a stop.
- Files on network drives skip the Recycle Bin (Windows deletes them directly).
- After replacing, relink textures in C4D (.png -> .tif) and set color space:
  sRGB for basecolor, Raw for all data maps.
