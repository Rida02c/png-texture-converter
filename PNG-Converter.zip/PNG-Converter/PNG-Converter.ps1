# PNG Converter - batch convert PNG texture maps to TIFF or JPG
#   Smart (default): TIFF ZIP; 16-bit kept for normal/height/displacement/bump/anisotropy,
#                    8-bit for color/roughness/metallic/AO/sheen/etc. (detected from file name)
#   TIFF           : lossless, keeps original bit depth (ZIP)
#   JPG            : 8-bit, adjustable quality
# Engine: ImageMagick (https://imagemagick.org)  -  UI: Windows Forms
param([string]$StartFolder = "")

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()

$AppName = "PNG Converter"

# ---------------------------------------------------------------- ImageMagick
function Find-Magick {
    $cmd = Get-Command magick.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    foreach ($root in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, (Join-Path $env:LOCALAPPDATA 'Programs'))) {
        if (-not $root -or -not (Test-Path $root)) { continue }
        $hit = Get-ChildItem -Path $root -Filter 'ImageMagick*' -Directory -ErrorAction SilentlyContinue |
               Sort-Object Name -Descending |
               ForEach-Object { Join-Path $_.FullName 'magick.exe' } |
               Where-Object { Test-Path $_ } |
               Select-Object -First 1
        if ($hit) { return $hit }
    }
    return $null
}

$magick = Find-Magick
if (-not $magick) {
    $r = [System.Windows.Forms.MessageBox]::Show(
        "ImageMagick (the free conversion engine) is not installed.`n`nInstall it now with winget (ImageMagick.Q16)?",
        $AppName, 'YesNo', 'Question')
    if ($r -eq 'Yes' -and (Get-Command winget.exe -ErrorAction SilentlyContinue)) {
        Start-Process winget.exe -ArgumentList @('install', '-e', '--id', 'ImageMagick.Q16') -Wait
        $magick = Find-Magick
    }
    if (-not $magick) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please install ImageMagick (Q16, x64) from imagemagick.org, then open this tool again.",
            $AppName, 'OK', 'Information') | Out-Null
        Start-Process 'https://imagemagick.org/download/'
        exit
    }
}
$magickVersion = (& $magick -version 2>&1 | Select-Object -First 1) -as [string]
if ($magickVersion -match '\bQ8\b') {
    [System.Windows.Forms.MessageBox]::Show(
        "Your ImageMagick build is Q8 and will reduce images to 8-bit.`nInstall the Q16 build to keep 16-bit maps.",
        $AppName, 'OK', 'Warning') | Out-Null
}

# ---------------------------------------------------------------- Hardware (for the Speed section)
$hw = @{ Threads = [Environment]::ProcessorCount; Cores = 0; RamGB = 0; Recommended = 2 }
try { $hw.Cores = [int](Get-CimInstance Win32_Processor | Measure-Object -Property NumberOfCores -Sum).Sum } catch { }
try { $hw.RamGB = [int][Math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB) } catch { }
if ($hw.Cores -lt 1) { $hw.Cores = [Math]::Max(1, [int]($hw.Threads / 2)) }
$recCpu = [Math]::Max(1, $hw.Cores - 1)                                   # leave one core free
$recRam = 2; if ($hw.RamGB -gt 0) { $recRam = [Math]::Max(1, [int][Math]::Floor($hw.RamGB / 4)) }  # ~1 GB per job + room for apps
$hw.Recommended = [Math]::Min($recCpu, $recRam)

# ---------------------------------------------------------------- Map type detection (Smart mode)
# Maps that need precision -> keep 16-bit
$Keys16 = @(
    'normal','normals','normalgl','normaldx','normalogl','normaldirectx','normalopengl','nrm','nor','norm','nml','n',
    'height','heightmap','hgt','h','displacement','displace','disp','dispmap','dsp','bump','bumpmap',
    'parallax','depth','vectordisplacement','vdisp','vdm',
    'anisotropic','anisotropy','aniso','anisotropyangle','anisotropyrotation','anisotropydirection',
    'rotation','flow','flowmap','direction','tangent'
)
# Maps where 8-bit is visually identical -> 8-bit
$Keys8 = @(
    'basecolor','basecolour','albedo','alb','diffuse','diff','dif','color','colour','col','d',
    'roughness','rough','rgh','r','gloss','glossiness','gls','smoothness',
    'metallic','metalness','metal','mtl','met','m',
    'ao','ambientocclusion','occlusion','occ','cavity','cav','curvature','curv',
    'sheen','sheencolor','sheenroughness','sheentint','fuzz',
    'specular','spec','specularlevel','reflection','refl','ior','s',
    'opacity','alpha','mask','transparency','transmission','translucency',
    'emissive','emission','emit','glow','selfillum',
    'sss','subsurface','scattering','coat','clearcoat','coatroughness','coatcolor',
    'arm','orm','rma','mra','mrao','packed',
    'preview','thumb','thumbnail','id','matid','materialid'
)
# Tokens ignored when reading a file name: sizes, ids, versions, normal conventions, filler
$SkipRx = '^(\d+k|\d+|\d+x\d+|gl|dx|ogl|opengl|directx|\d+bit|lod\d*|var\d*|v\d+|map|tex|texture|final|hi|lo)$'

function Get-MapClass([string]$baseName) {
    $tokens = @($baseName.ToLower() -split '[\s_\-\.\(\)\[\]]+' | Where-Object { $_ -and ($_ -notmatch $SkipRx) })
    if ($tokens.Count -eq 0) { return @{ Bits = 'keep'; Type = 'unknown' } }
    # 1) the last meaningful token is normally the map type (e.g. "... metal height 8k", "..._8690_Normal")
    $last = $tokens[$tokens.Count - 1]
    if ($Keys16 -contains $last) { return @{ Bits = '16'; Type = $last } }
    if ($Keys8  -contains $last) { return @{ Bits = '8';  Type = $last } }
    # compound names: transmissionweight, transmissioncolor, sheenweight, coatcolour, emissionamount ...
    if ($last -match '^(transmission|subsurface|sss|sheen|coat|clearcoat|specular|spec|emission|emissive|base|diffuse|thinfilm|fuzz|opacity|metal|metallic|rough|roughness)\w*$' -or
        $last -match '\w{3,}(weight|color|colour|tint|amount|level|strength|mask)$') { return @{ Bits = '8'; Type = $last } }
    # 2) fallback: any longer keyword in the name, precision maps win
    foreach ($t in $tokens) { if ($t.Length -ge 4 -and $Keys16 -contains $t) { return @{ Bits = '16'; Type = $t } } }
    for ($i = $tokens.Count - 1; $i -ge 0; $i--) {
        $t = $tokens[$i]
        if ($t.Length -ge 4 -and $Keys8 -contains $t) { return @{ Bits = '8'; Type = $t } }
    }
    return @{ Bits = 'keep'; Type = 'unknown' }
}

# ---------------------------------------------------------------- UI helpers
function New-Ctl($type, $x, $y, $w, $h, $text) {
    $c = New-Object ("System.Windows.Forms." + $type)
    $c.Location = New-Object System.Drawing.Point($x, $y)
    if ($w -gt 0) { $c.Size = New-Object System.Drawing.Size($w, $h) }
    if ($text) { $c.Text = $text }
    return $c
}

$font = New-Object System.Drawing.Font('Segoe UI', 9)
$form = New-Object System.Windows.Forms.Form
$form.Text = $AppName
$form.ClientSize = New-Object System.Drawing.Size(640, 730)
$form.StartPosition = 'CenterScreen'
$form.Font = $font
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.AllowDrop = $true

# Source
$lblSrc    = New-Ctl Label 14 14 400 18 "Source folder (or drag a folder onto this window)"
$txtSrc    = New-Ctl TextBox 14 34 520 24 $StartFolder
$btnSrc    = New-Ctl Button 542 32 84 27 "Browse..."
$chkSub    = New-Ctl CheckBox 14 64 300 22 "Include subfolders"

# Format
$grpFmt    = New-Ctl GroupBox 14 94 612 124 "Output format"
$rbSmart   = New-Ctl RadioButton 14 22 590 22 "Smart TIFF  -  16-bit for normal / height / disp / bump, 8-bit for the rest (saves space)"
$rbTiff    = New-Ctl RadioButton 14 50 590 22 "TIFF  -  lossless, keeps original bit depth for every map"
$rbJpg     = New-Ctl RadioButton 14 78 200 22 "JPG  -  8-bit, quality:"
$numQ      = New-Ctl NumericUpDown 216 77 60 24 $null
$numQ.Minimum = 1; $numQ.Maximum = 100; $numQ.Value = 95
$rbSmart.Checked = $true
$grpFmt.Controls.AddRange(@($rbSmart, $rbTiff, $rbJpg, $numQ))

# Output location
$grpOut    = New-Ctl GroupBox 14 228 612 112 "Output location"
$rbReplace = New-Ctl RadioButton 14 22 580 22 "Replace originals  (PNG goes to Recycle Bin after a successful convert)"
$rbSep     = New-Ctl RadioButton 14 50 200 22 "Separate folder:"
$txtOut    = New-Ctl TextBox 30 76 476 24 ""
$btnOut    = New-Ctl Button 514 74 84 27 "Browse..."
$rbSep.Checked = $true
$grpOut.Controls.AddRange(@($rbReplace, $rbSep, $txtOut, $btnOut))

# Options
$chkSkip   = New-Ctl CheckBox 14 350 260 22 "Skip files already converted"
$chkSkip.Checked = $true

# Speed (can be changed while converting)
$grpSpeed  = New-Ctl GroupBox 14 378 612 84 "Speed  (can be changed while converting)"
$lblCores  = New-Ctl Label 14 26 120 20 "CPU cores to use:"
$numCores  = New-Ctl NumericUpDown 134 23 50 24 $null
$numCores.Minimum = 1; $numCores.Maximum = $hw.Threads; $numCores.Value = $hw.Recommended
$lblOf     = New-Ctl Label 190 26 70 20 ("of " + $hw.Threads)
$btnRec    = New-Ctl Button 262 21 150 27 ("Recommended (" + $hw.Recommended + ")")
$chkLow    = New-Ctl CheckBox 430 24 170 22 "Low priority"
$chkLow.Checked = $true
$lblHw     = New-Ctl Label 14 54 590 20 ("Your PC: {0} cores / {1} threads, {2} GB RAM.  Each core converts one file at a time (~1 GB RAM per 8K file)." -f $hw.Cores, $hw.Threads, $hw.RamGB)
$lblHw.ForeColor = [System.Drawing.Color]::DimGray
$grpSpeed.Controls.AddRange(@($lblCores, $numCores, $lblOf, $btnRec, $chkLow, $lblHw))
$tip = New-Object System.Windows.Forms.ToolTip
$tip.SetToolTip($chkLow, "Windows gives other apps (C4D, browser) priority, so the PC stays responsive.")
$tip.SetToolTip($numCores, "Number of files converted at the same time. More = faster, uses more CPU and RAM.")

# Run
$btnGo     = New-Ctl Button 14 474 120 32 "Convert"
$btnStop   = New-Ctl Button 142 474 90 32 "Stop"
$btnStop.Enabled = $false
$lblStatus = New-Ctl Label 244 482 382 20 "Ready."
$bar       = New-Ctl ProgressBar 14 516 612 18 $null
$txtLog    = New-Ctl TextBox 14 542 612 176 ""
$txtLog.Multiline = $true; $txtLog.ScrollBars = 'Vertical'; $txtLog.ReadOnly = $true
$txtLog.Font = New-Object System.Drawing.Font('Consolas', 8.5)

$form.Controls.AddRange(@($lblSrc, $txtSrc, $btnSrc, $chkSub, $grpFmt, $grpOut,
    $chkSkip, $grpSpeed, $btnGo, $btnStop, $lblStatus, $bar, $txtLog))

$btnRec.Add_Click({ $numCores.Value = $hw.Recommended })
$chkLow.Add_CheckedChanged({
    $prio = 'Normal'; if ($chkLow.Checked) { $prio = 'BelowNormal' }
    foreach ($job in @($state.Running)) { try { if (-not $job.Proc.HasExited) { $job.Proc.PriorityClass = $prio } } catch { } }
})

function Log($msg) { $txtLog.AppendText($msg + "`r`n") }
function Fmt-MB($bytes) { "{0:N0} MB" -f ($bytes / 1MB) }

function Update-OutState {
    $txtOut.Enabled = $rbSep.Checked
    $btnOut.Enabled = $rbSep.Checked
    $numQ.Enabled = $rbJpg.Checked
}
function Set-DefaultOut {
    if ($txtSrc.Text -and (-not $txtOut.Text -or $txtOut.Tag -eq 'auto')) {
        $txtOut.Text = Join-Path $txtSrc.Text.TrimEnd('\') 'converted'
        $txtOut.Tag = 'auto'
    }
}
function Pick-Folder($initial) {
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    if ($initial -and (Test-Path -LiteralPath $initial)) { $dlg.SelectedPath = $initial }
    if ($dlg.ShowDialog($form) -eq 'OK') { return $dlg.SelectedPath }
    return $null
}

$rbSep.Add_CheckedChanged({ Update-OutState })
$rbJpg.Add_CheckedChanged({ Update-OutState })
$txtSrc.Add_TextChanged({ Set-DefaultOut })
$txtOut.Add_KeyPress({ $txtOut.Tag = 'user' })
$btnSrc.Add_Click({ $p = Pick-Folder $txtSrc.Text; if ($p) { $txtSrc.Text = $p } })
$btnOut.Add_Click({ $p = Pick-Folder $txtOut.Text; if ($p) { $txtOut.Text = $p; $txtOut.Tag = 'user' } })
$form.Add_DragEnter({ if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop)) { $_.Effect = 'Copy' } })
$form.Add_DragDrop({
    $p = @($_.Data.GetData([Windows.Forms.DataFormats]::FileDrop))[0]
    if (Test-Path -LiteralPath $p -PathType Container) { $txtSrc.Text = $p }
    elseif (Test-Path -LiteralPath $p) { $txtSrc.Text = Split-Path $p -Parent }
})
Update-OutState
Set-DefaultOut

# ---------------------------------------------------------------- Job engine
$state = @{
    Queue   = New-Object System.Collections.Queue
    Running = New-Object System.Collections.ArrayList
    Total = 0; Done = 0; Ok = 0; Failed = 0; Skipped = 0
    InBytes = [int64]0; OutBytes = [int64]0
    Replace = $false; Stop = $false
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 200

function Set-Busy($busy) {
    foreach ($c in @($txtSrc, $btnSrc, $chkSub, $grpFmt, $grpOut, $chkSkip, $btnGo)) { $c.Enabled = -not $busy }
    $btnStop.Enabled = $busy
    if (-not $busy) { Update-OutState }
}

function Start-Job1($job) {
    New-Item -ItemType Directory -Force -Path (Split-Path $job.Tmp -Parent) | Out-Null
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $magick
    $psi.Arguments = $job.Args
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardError = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    if ($chkLow.Checked) { try { $p.PriorityClass = 'BelowNormal' } catch { } }
    $job.Proc = $p
    $job.Err = $p.StandardError.ReadToEndAsync()
    [void]$state.Running.Add($job)
}

function Finish-Job($job) {
    $p = $job.Proc
    $ok = ($p.ExitCode -eq 0) -and (Test-Path -LiteralPath $job.Tmp) -and ((Get-Item -LiteralPath $job.Tmp).Length -gt 0)
    if ($ok) {
        try {
            $inLen = (Get-Item -LiteralPath $job.Src).Length
            if (Test-Path -LiteralPath $job.Dst) { Remove-Item -LiteralPath $job.Dst -Force }
            Move-Item -LiteralPath $job.Tmp -Destination $job.Dst -Force
            $outLen = (Get-Item -LiteralPath $job.Dst).Length
            if ($state.Replace) {
                [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($job.Src, 'OnlyErrorDialogs', 'SendToRecycleBin')
            }
            $state.InBytes += $inLen; $state.OutBytes += $outLen
            $state.Ok++
            Log ("OK    {0}  [{1}]  {2} -> {3}" -f $job.Name, $job.Label, (Fmt-MB $inLen), (Fmt-MB $outLen))
        } catch {
            $state.Failed++
            Log ("FAIL  " + $job.Name + "  -  " + $_.Exception.Message)
        }
    } else {
        $state.Failed++
        $err = ""
        try { $err = ($job.Err.Result -replace '\s+', ' ').Trim() } catch { }
        Log ("FAIL  " + $job.Name + "  -  exit " + $p.ExitCode + "  " + $err)
        if (Test-Path -LiteralPath $job.Tmp) { Remove-Item -LiteralPath $job.Tmp -Force -ErrorAction SilentlyContinue }
    }
    $p.Dispose()
    $state.Done++
}

$timer.Add_Tick({
    foreach ($job in @($state.Running)) {
        if ($job.Proc.HasExited) {
            $state.Running.Remove($job)
            Finish-Job $job
        }
    }
    while (-not $state.Stop -and $state.Queue.Count -gt 0 -and $state.Running.Count -lt [int]$numCores.Value) {
        Start-Job1 $state.Queue.Dequeue()
    }
    $bar.Value = [Math]::Min($bar.Maximum, $state.Done + $state.Skipped)
    $lblStatus.Text = "{0} / {1}   ({2} running)" -f ($state.Done + $state.Skipped), $state.Total, $state.Running.Count

    if ($state.Running.Count -eq 0 -and ($state.Queue.Count -eq 0 -or $state.Stop)) {
        $timer.Stop()
        $state.Queue.Clear()
        $summary = "Finished: {0} converted, {1} failed, {2} skipped." -f $state.Ok, $state.Failed, $state.Skipped
        if ($state.Stop) { $summary = "Stopped. " + $summary }
        Log ""; Log $summary
        if ($state.InBytes -gt 0) {
            $pct = [Math]::Round(100 * (1 - $state.OutBytes / $state.InBytes))
            $sizeLine = "Size: {0} -> {1}  ({2}% smaller)" -f (Fmt-MB $state.InBytes), (Fmt-MB $state.OutBytes), $pct
            if ($pct -lt 0) { $sizeLine = "Size: {0} -> {1}  ({2}% larger)" -f (Fmt-MB $state.InBytes), (Fmt-MB $state.OutBytes), (-$pct) }
            Log $sizeLine
            $summary = $summary + "  " + $sizeLine
        }
        $lblStatus.Text = $summary
        Set-Busy $false
    }
})

$btnStop.Add_Click({
    $state.Stop = $true
    $lblStatus.Text = "Stopping after current files..."
})

$btnGo.Add_Click({
    $src = $txtSrc.Text.Trim().TrimEnd('\')
    if (-not $src -or -not (Test-Path -LiteralPath $src -PathType Container)) {
        [System.Windows.Forms.MessageBox]::Show("Choose a valid source folder.", $AppName) | Out-Null; return
    }
    $replace = $rbReplace.Checked
    $outRoot = $txtOut.Text.Trim().TrimEnd('\')
    if (-not $replace -and -not $outRoot) {
        [System.Windows.Forms.MessageBox]::Show("Choose an output folder.", $AppName) | Out-Null; return
    }
    $mode = 'smart'
    if ($rbTiff.Checked) { $mode = 'tiff' }
    if ($rbJpg.Checked)  { $mode = 'jpg' }
    $ext = 'tif'; if ($mode -eq 'jpg') { $ext = 'jpg' }

    $files = @(Get-ChildItem -LiteralPath $src -Filter '*.png' -File -Recurse:$chkSub.Checked -ErrorAction SilentlyContinue)
    if (-not $replace) {
        $files = @($files | Where-Object { -not $_.FullName.StartsWith($outRoot + '\', [StringComparison]::OrdinalIgnoreCase) })
    }
    if ($files.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No PNG files found.", $AppName) | Out-Null; return
    }
    if ($replace) {
        $r = [System.Windows.Forms.MessageBox]::Show(
            ("Convert {0} PNG file(s) to {1} and move the original PNGs to the Recycle Bin?" -f $files.Count, $ext.ToUpper()),
            $AppName, 'OKCancel', 'Warning')
        if ($r -ne 'OK') { return }
    }

    $tiffArgs = '-compress Zip -define tiff:predictor=2'
    $jpgArgs  = '-background white -alpha remove -alpha off -depth 8 -sampling-factor 4:4:4 -quality ' + [int]$numQ.Value

    $state.Queue.Clear(); $state.Running.Clear()
    $state.Total = $files.Count; $state.Done = 0; $state.Ok = 0; $state.Failed = 0; $state.Skipped = 0
    $state.InBytes = [int64]0; $state.OutBytes = [int64]0
    $state.Replace = $replace; $state.Stop = $false
    $txtLog.Clear()
    Log ("Engine: " + $magickVersion)
    $modeName = @{ smart = 'Smart TIFF'; tiff = 'TIFF (lossless)'; jpg = 'JPG' }[$mode]
    Log ("{0} PNG file(s) -> {1}{2}" -f $files.Count, $modeName, $(if ($replace) { ' (replace)' } else { '  into  ' + $outRoot }))
    Log ""

    foreach ($f in $files) {
        if ($replace) { $dir = $f.DirectoryName }
        else {
            $rel = $f.DirectoryName.Substring($src.Length).TrimStart('\')
            $dir = if ($rel) { Join-Path $outRoot $rel } else { $outRoot }
        }
        $dst = Join-Path $dir ($f.BaseName + '.' + $ext)
        $name = $f.FullName.Substring($src.Length).TrimStart('\')
        if ($chkSkip.Checked -and (Test-Path -LiteralPath $dst)) {
            $state.Skipped++
            Log ("SKIP  " + $name + "  (exists)")
            continue
        }

        switch ($mode) {
            'smart' {
                $cls = Get-MapClass $f.BaseName
                if ($cls.Bits -eq '8') { $fmtArgs = '-depth 8 ' + $tiffArgs; $label = $cls.Type + ': 8-bit' }
                elseif ($cls.Bits -eq '16') { $fmtArgs = $tiffArgs; $label = $cls.Type + ': keep 16-bit' }
                else { $fmtArgs = $tiffArgs; $label = 'unrecognized: original depth' }
            }
            'tiff' { $fmtArgs = $tiffArgs; $label = 'lossless' }
            'jpg'  { $fmtArgs = $jpgArgs;  $label = 'jpg q' + [int]$numQ.Value }
        }

        $tmp = Join-Path $dir ($f.BaseName + '.__converting__.' + $ext)
        $magickArgs = '-quiet -limit thread 1 -define filename:literal=true "{0}" {1} "{2}"' -f $f.FullName, $fmtArgs, $tmp
        $state.Queue.Enqueue(@{ Src = $f.FullName; Dst = $dst; Tmp = $tmp; Name = $name; Label = $label; Args = $magickArgs })
    }

    $bar.Minimum = 0; $bar.Maximum = [Math]::Max(1, $state.Total); $bar.Value = 0
    Set-Busy $true
    $timer.Start()
})

$form.Add_FormClosing({
    if ($state.Running.Count -gt 0) {
        $r = [System.Windows.Forms.MessageBox]::Show("Conversion is running. Stop and close?", $AppName, 'YesNo', 'Warning')
        if ($r -ne 'Yes') { $_.Cancel = $true; return }
        $timer.Stop()
        foreach ($job in @($state.Running)) {
            try { if (-not $job.Proc.HasExited) { $job.Proc.Kill(); $job.Proc.WaitForExit(3000) } } catch { }
            if (Test-Path -LiteralPath $job.Tmp) { Remove-Item -LiteralPath $job.Tmp -Force -ErrorAction SilentlyContinue }
        }
    }
})

[void]$form.ShowDialog()
